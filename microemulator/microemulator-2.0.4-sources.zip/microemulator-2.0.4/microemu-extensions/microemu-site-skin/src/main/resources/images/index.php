<?php
    header("Location: http:///www.microemu.org/");
    exit;
?>
