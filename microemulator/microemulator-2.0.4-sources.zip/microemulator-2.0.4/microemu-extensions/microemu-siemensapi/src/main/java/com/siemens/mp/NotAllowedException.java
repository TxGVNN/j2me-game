/*
 * NotAllowedException.java
 *
 * Created on 25. September 2003, 11:35
 */

package com.siemens.mp;

/**
 *
 * @author  Markus
 */
public class NotAllowedException extends Exception{
    
   
}
