#! /bin/sh
#  @version $Revision: 915 $ ($Author: barteo $) $Date: 2007-02-14 04:20:35 -0500 (Wed, 14 Feb 2007) $
#


cp subversion_config ${HOME}/.subversion/config

